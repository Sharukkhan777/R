fluidPage( tabsetPanel(
  tabPanel("tab 1", h1("contents")),
  tabPanel("tab 2", h1("contents")),
  tabPanel("tab 3", h1("contents"))))