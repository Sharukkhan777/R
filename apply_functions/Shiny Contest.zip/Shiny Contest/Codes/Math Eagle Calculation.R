library(shiny)
# library(shinymaterial)

ui <- fluidPage(
  h1("Math Eagle...!!!"),
  hr(),
  h4("Text Output"),
  textOutput(outputId = "question"),
  # textInput(inputId = "ans",label = "Answer", autofocus="autofocus"),
  HTML('<input type="text" name="name" id="xax" autofocus="autofocus" />'),
  hr(),
  div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "one",label = "1")),
  div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "two",label = "2")),
  div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "three",label = "3")),
  br(),
  br(),
  div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "four",label = "4")),
  div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "five",label = "5")),
  div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "six",label = "6")),
  br(),
  br(),
  div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "seven",label = "7")),
  div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "eight",label = "8")),
  div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "nine",label = "9")),
  br(),
  br(),
  div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "point_",label = "-")),
  div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "zero",label = "0")),
  div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "enter",label = "Enter"))
  
)

server <- function(input, output, session) {
  # random number 1
  randnum1 = as.character(round(runif(1, min=1, max=15)))
  # random number 2
  randnum2 = as.character(round(runif(1, min=1, max=15)))
  # symbol
  randsym = sample(c("+","-","*"),1)
  # calculate answer
  rv <- reactiveValues()
  ans_str = paste(randnum1,randsym,randnum2)
  output$question <- renderText({ans_str})
  ans = as.character(eval(parse(text=ans_str)))
  print(ans)
  # create empty string
  
  rv$ans_str_entry <- ""

  observeEvent(input$one, {rv$ans_str_entry <- paste(rv$ans_str_entry,"1",sep='')})
  observeEvent(input$two, {rv$ans_str_entry <- paste(rv$ans_str_entry,"2",sep='')})
  observeEvent(input$three, {rv$ans_str_entry <- paste(rv$ans_str_entry,"3",sep='')})
  observeEvent(input$four, {rv$ans_str_entry <- paste(rv$ans_str_entry,"4",sep='')})
  observeEvent(input$five, {rv$ans_str_entry <- paste(rv$ans_str_entry,"5",sep='')})
  observeEvent(input$six, {rv$ans_str_entry <- paste(rv$ans_str_entry,"6",sep='')})
  observeEvent(input$seven, {rv$ans_str_entry <- paste(rv$ans_str_entry,"7",sep='')})
  observeEvent(input$eight, {rv$ans_str_entry <- paste(rv$ans_str_entry,"8",sep='')})
  observeEvent(input$nine, {rv$ans_str_entry <- paste(rv$ans_str_entry,"9",sep='')})
  observeEvent(input$zero, {rv$ans_str_entry <- paste(rv$ans_str_entry,"0",sep='')})
  observeEvent(input$point_, {rv$ans_str_entry <- paste(rv$ans_str_entry,"-",sep='')})
  observeEvent(input$enter, {
    print(rv$ans_str_entry)
    print(class(rv$ans_str_entry))
    if(rv$ans_str_entry == ans){
      print("Green")
    }else{
      print("Red")
    }
    rv$ans_str_entry <- ""
  })
  
  
}

shinyApp(ui, server)