library(shiny)

ui <- fluidPage( includeCSS("www/style.css"),
                 tabsetPanel(
  tabPanel("Intro", h1("Math Eagle..!!")),
  tabPanel("Game", 
           # eagle map
           fluidRow(column(width = 12),img(style="height=12",src="earth_cropped.png")),
           # Game 
           sidebarLayout(
             # scores and timer
    sidebarPanel(verticalLayout( splitLayout(img(src="timer.png",height="70", widht="300"),h6("Score")),img(src="eagleBubbleText.png",height="200", widht="200"))),
    mainPanel(HTML('
             <div class="myDiv">
                  <br>
                  <br>      
                  <br>
                  <br>      
                  <br>
                  <img class="eagle" src="eaglefly.gif" alt="Eagle" width="250" height="250">
                  <img class="spacecapsule" id="sc" src="space capsule.png" width="150" height="150">
                  <img class="corner" src="corner img.png" width="150" height="150">
                  </div>'
              ),
              hr(),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "one",style = "width:50px",label = "1")),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "two",style = "width:50px",label = "2")),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "three",style = "width:50px",label = "3")),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "four",style = "width:50px",label = "4")),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "five",style = "width:50px",label = "5")),
              br(),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "six",style = "width:50px",label = "6")),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "seven",style = "width:50px",label = "7")),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "eight",style = "width:50px",label = "8")),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "nine",style = "width:50px",label = "9")),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "zero",style = "width:50px",label = "0")),
              br(),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "point_",style = "width:50px",label = "-")),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "enter",style = "width:150px",label = "Enter")))
            )
           ),
  tabPanel("Stats", h1("contents3")),
  tabPanel("About", h1("contents4"))))

server <- function(input, output, session) {
  
}

shinyApp(ui, server)