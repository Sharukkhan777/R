library(shiny)



function(input, output, session) {
  
}

shinyApp(ui, server)