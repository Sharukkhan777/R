#==================================
#==================================
# -------HELPER FUNCTON------------
#==================================
#==================================

#--------TIMER------------------
# add zero for single digit
add_zero <- function(x){
  x <- as.character(x)
  if (nchar(x) == 1) {
    ans_str <- paste("0", x, sep = "")    
  }else{
    ans_str <- x
  }
  return(ans_str)
}
#-------------------------------
# make a timer str
timer_str <- c("02 : 00")
min <- 1
sec <- 59
for (i in 1:120) {
  ans_str <- paste(add_zero(min),":", add_zero(sec))
  timer_str <- c(timer_str, ans_str)
  
  sec <- sec - 1
  if (sec == -1) {
    min <- min - 1
    sec <- 59
  }
}
timer_str <- rev(timer_str)










source("helper_functions.R")
#==================================
#==================================
# ----------APPLICATION------------
#==================================
#==================================

library(lubridate)
library(shiny)

ui <- fluidPage( includeCSS("www/style.css"),
                 tabsetPanel(id = "inTabset",
  tabPanel("Intro", 
           h1("Math Eagle..!!"),
           actionButton(inputId = "startGame",label = "Start")),
  tabPanel("Game", 
           br(),
           # Game 
           sidebarLayout(
             # scores and timer
    sidebarPanel(verticalLayout( splitLayout(textOutput("timer")
                                             ,h6("Score"))
                                            ,div(class="signal"))),
    mainPanel(verticalLayout(img(class="earth_crop", src="earth_cropped.png"),
                             img(class="nav_eagle", src="nav_eagle.png"),
              br(),
              HTML('
             <div class="myDiv">
                  <br>
                  <br>
                  <br>
                  <h3 class="ans_txt" >1 + 2 =</h3>
                  &emsp;&emsp;&emsp;&emsp;&emsp;
                  <img class="bt" src="bubbleTextImage.png" width="150" height="90">
                  <br>
                  <img class="eagle" src="eaglefly.gif" alt="Eagle" width="250" height="250">
                  </div>'
              )),
              hr(),
              fluidRow(column(width = 5,
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "one",style = "width:50px",label = "1")),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "two",style = "width:50px",label = "2")),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "three",style = "width:50px",label = "3")),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "four",style = "width:50px",label = "4")),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "five",style = "width:50px",label = "5")),
              br(),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "six",style = "width:50px",label = "6")),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "seven",style = "width:50px",label = "7")),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "eight",style = "width:50px",label = "8")),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "nine",style = "width:50px",label = "9")),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "zero",style = "width:50px",label = "0"))
              ),
              column(width = 4,offset = 0,
                div(actionButton(class = "enter",inputId = "enter",style = "width:265px",label = "Enter")))
              ))
              
            )
           ),
  tabPanel("Stats", h1("contents3")),
  tabPanel("About", h1("contents4"))))

server <- function(input, output, session) {
  # go to page two by clicking the start button in the page 1
  observeEvent(input$startGame,{
    updateTabsetPanel(session,"inTabset",selected = "Game")
  })
  
  #=======================================
  #-------TIMER--------
  # initialize the timer
  timer_count <- reactiveVal(121)
  active <- reactiveVal(FALSE)
  # output
  output$timer <- renderText({timer_str[timer_count()]})
  # observer that invalidates every second.
  observe({
    invalidateLater(1000, session)
    isolate({
      if(active())
      {
        timer_count(timer_count()-1)
        if (timer_count()<1) {
          active(FALSE)
          showModal(modalDialog(
            title = "Important message",
            "Countdown completed"
          ))
        }
      }
    })
  })
  # start Game
  observeEvent(input$startGame, {active(TRUE)})
  
  #=======================================
  
}

shinyApp(ui, server)