library(shiny)

ui <- fluidPage( includeCSS("www/style.css"),
                 tabsetPanel(
  tabPanel("Intro", h1("Math Eagle..!!")),
  tabPanel("Game", 
           br(),
           # Game 
           sidebarLayout(
             # scores and timer
    sidebarPanel(verticalLayout( splitLayout(h1(id="timer","02:00"),h6("Score")),div(class="signal"))),
    mainPanel(verticalLayout(img(class="earth_crop", src="earth_cropped.png"),
              br(),
              HTML('
             <div class="myDiv">
                  <br>
                  <br>
                  <br>
                  <h3 class="ans_txt" >1 + 2 =</h3>
                  &emsp;&emsp;&emsp;&emsp;&emsp;
                  <img class="bt" src="bubbleTextImage.png" width="150" height="90">
                  <br>
                  <img class="eagle" src="eaglefly.gif" alt="Eagle" width="250" height="250">
                  </div>'
              )),
              hr(),
              fluidRow(column(width = 6,
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "one",style = "width:50px",label = "1")),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "two",style = "width:50px",label = "2")),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "three",style = "width:50px",label = "3")),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "four",style = "width:50px",label = "4")),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "five",style = "width:50px",label = "5")),
              br(),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "six",style = "width:50px",label = "6")),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "seven",style = "width:50px",label = "7")),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "eight",style = "width:50px",label = "8")),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "nine",style = "width:50px",label = "9")),
              div(style="display: inline-block;vertical-align:top; width: 50px;",actionButton(inputId = "zero",style = "width:50px",label = "0"))
              ),
              column(width = 2,offset = 0,
                div(actionButton(class = "enter",inputId = "enter",label = "Enter",style = "width:300px")))
              ))
              
            )
           ),
  tabPanel("Stats", h1("contents3")),
  tabPanel("About", h1("contents4"))))

server <- function(input, output, session) {
  
}

shinyApp(ui, server)